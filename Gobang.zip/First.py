import numpy as np
import random
import time
from pprint import pprint
import sys

COLOR_BLACK = -1
COLOR_WHITE = 1
COLOR_NONE = 0
random.seed(0)


class Node:
    def __init__(self, role, isAI, board, parent=None, x=-1, y=-1):  # the parent of root node is always None
        self.role = role
        if x != -1:  # the first node do not have x y
            board[x][y] = role[isAI]

        self.board = board
        self.value = None
        self.alpha = -np.inf
        self.beta = np.inf
        self.isAI = isAI
        self.parent = parent
        self.children = []

    def _heuristic_test_1(self, board, chessman, center):
        mark = 0;

        len_range = range(len(board))
        # board = list(zip(*[(board[x, x], board[14 - x, x], board[center[0], x], board[x, center[1]]) for x in len_range]))#
        # not true, to be done

        board.append()

    def _heuristic_test_2(self, board, chessman, center):
        mark = 0

    def heuristic_evaluate(self, move):
        x, y = move
        board = self.board
        chessman = self.role[self.isAI]  # the represent of testing partern (-1 or 1)

        board[x][y] = chessman
        board_size = len(board)
        mark = 0  # the returned value of heuristic definition

        # Tirstly, testing the 4 directions line in 9*9 board
        test_board1 = board[max(0, x - 4): min(board_size, x + 5), max(0, y - 4): min(board_size, y + 5)]
        center1 = (min(4, x), min(4, y))
        mark += self._heuristic_test_1(test_board1, chessman)

        # Then, testing the 8 grids and 8 groups in 5*5 board
        test_board2 = board[max(0, x - 2): min(board_size, x + 3), max(0, y - 2): min(board_size, y + 3)]
        center2 = (min(2, x), min(2, y))
        mark += self._heuristic_test_2(test_board1, chessman, center2)

        return mark

    def generate(self):  # generate the available move, then use heuristic evaluation to sort
        available_move = (self.board == 0).nonzero()
        available_move = list(zip(available_move[0], available_move[1]))
        heuris_fn = self.heuristic_evaluate if self.isAI else lambda x: -self.heuristic_evaluate(x)  # human --> -1
        available_move = sorted(available_move, key=heuris_fn)

        return available_move

    def propagete_ab(self):  # update the alpha/beta value of parent and siblings
        if self.parent.isAI and self.value > self.parent.alpha:
            self.parent.alpha = self.value
            for child in self.parent.children:
                child.alpha = self.value
        elif not self.parent.isAI and self.value < self.parent.beta:
            self.parent.beta = self.value
            for child in self.parent.children:
                child.beta = self.value

    def propagate_value(self):
        if self.parent:
            self.parent.value = max(self.parent.children, lambda child: child.value)
            return True

        return False

    def evaluate(self):  # evaluate function that define the condition fo board, only used in leaf node
        board = self.board


class AI(object):
    # chessboard_size, color, time_out passed from agent
    def __init__(self, chessboard_size, color, time_out):
        self.chessboard_size = chessboard_size
        self.color = color
        self.role = {True: color, False: -1 if color == 1 else 1}
        # the max time you should use, your algorithm’s run time must not exceed the time limit.
        self.time_out = time_out
        self.candidate_list = []

    def go(self, chessboard):
        # Clear candidate_list
        self.candidate_list.clear()
        # ==================================================================
        # To write your algorithm here
        # Here is the simplest sample:Random decision

        node = Node(1, True, chessboard)
        print(node.board)

        available_move = node.generate()
        print(available_move)

        pos_idx = random.randint(0, len(available_move) - 1)
        new_pos = available_move[pos_idx]
        # ==============Find new pos========================================
        # Make sure that the position of your decision in chess board is empty.
        # If not, return error.
        assert chessboard[new_pos[0], new_pos[1]] == 0
        # Add your decision into candidate_list, Records the chess board
        self.candidate_list.append(new_pos)


if __name__ == '__main__':
    chessboard: np.ndarray = np.random.choice((0, 1, -1), (15, 15), p=(0.8, 0.1, 0.1))
    chessboard_size = 15
    color = 1
    time_out = 3

    test_ai = AI(chessboard_size, color, time_out)
    test_ai.go(chessboard)
