import sys
import numpy as np


x, y = 1, 4
center = (min(2, x), min(2, y))
print(center)